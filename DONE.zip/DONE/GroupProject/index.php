<?php
/*
* Author: Evan Deal
* Date: today's date
* Name: index.php
* Description:
*/
$page_title = "Colts Merchandise Home";

include('includes/header.php');
?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <link type="text/css" rel="stylesheet" href="www/css/style.css"/>
        <style>
            body {
                background-image: url("www/img/stadium.jpg");
                background-size: cover;
                background-position: center;
                position:relative;
            }
        </style>
    </head>
<div class="bodyBorder">
    <body>
    <title>The Indianapolis Colts</title>
    <h1> Welcome to the Indianapolis Colts Home Page! </h1>
    <h2> Your one stop shop for all of your Colts Needs!</h2>

    <p> At the Colts, we offer peak amentities for your gameday needs</p>
    <P> Amentities include </P>

        <ul> Comforting Seating</ul>
        <ul> Afforable Snacks and Drinks</ul>
        <ul> Great Prices on tickets</ul>
        <ul> Parking Passes</ul>
        <ul> Jersey Sales</ul>
        <ul> Much more</ul>

</div>
    </body>
    </html>
<?php
include('includes/footer.php');
