</div>
<div id="footer">
    <hr width="95%" />
    &copy <?php echo date("Y") ?> COLTS PHP Online Shop. All Rights Reserved.
</div>
</div>

</body>
</html>