<?php
/**
 * Author: Evan Deal
 * Date: ${Date}
 * File: library.php
 * Description:
 */

function is_admin()
{
    if (session_status() == PHP_SESSION_NONE) {
        session_start();
    }
    if (isset($_SESSION['role'])) {
        $role = $_SESSION['role'];
    }
    return ($role == 1) ? true : false;
}