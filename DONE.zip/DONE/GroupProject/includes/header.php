<?php
//determining status and starting session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

//creating a variable to store the amount of items in a cart
$count = 0;

//retrieve cart content
if (isset($_SESSION['cart'])) {
    $cart = $_SESSION['cart'];

    if ($cart) {
        $count = array_sum($cart);
    }
}

//set shopping cart image
$shoppingcart_img = (!$count) ? "shopping_cart_empty.png" : "shoppingcart_full.png";

//variables for a user’s login, name, and role
$login = '';
$name = '';
$role = 0;
//if the use has logged in, retrieve login, name, and role.
if (isset($_SESSION['login']) AND isset($_SESSION['name']) AND
    isset($_SESSION['role'])) {
    $login = $_SESSION['login'];
    $name = $_SESSION['name'];
    $role = $_SESSION['role'];
}
?>


<!DOCTYPE HTML>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link type="text/css" rel="stylesheet" href="www/css/style.css"/>
    <title><?php echo $page_title; ?></title>
</head>
<body>

<div id="wrapper">
    <!-- div tag to create Colt's title -->
    <div id="banner">
        <h1>For the Shoe</h1>
        <!-- we can make a dif div so we can keep it side by side but imma do that another time -->
        <img src="https://content.sportslogos.net/logos/7/158/full/indianapolis_colts_logo_primary_20043652.png"
             style="height: 50px;">
        <div class="right-align">
            <a href="showcart.php">
                <img src='www/img/<?= $shoppingcart_img ?>' alt='Shopping cart' style='width: 100px'><br>
                <span> <?= $count ?> item(s) </span>
            </a>
        </div>
    </div>
    <!-- navigation bar -->
    <div style="justify-content: center" id="navbar">

        <!-- here is where we can add tabs like log in or home page etc -->
        <div class="navlink">
            <a href="index.php">Home Page</a> || <a href="products.php">Products</a>
            || <a href="searchproducts.php">Search</a> ||
            <!-- here is where we can add tabs like log in or home page etc -->
            <?php
            if ($role == 1) {
                echo "<a href='addproduct.php'>Add Product</a> || ";
            }
            if (empty($login))
                echo "<a href='loginform.php'>Login/Register</a>";
            else {
                echo "<a href='logout.php'>Logout</a>";
                echo "<span style='color:red; margin-left:30px'>Welcome $name!</span>";
            }
            ?>
        </div>


    </div>

    <!-- you could add a search bar here -->

    <div id="pagespecific">

    </div>
    <!-- main content body starts -->
    <div id="mainbody">