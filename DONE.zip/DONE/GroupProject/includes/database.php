<?php
/**
 * Author: Evan Deal
 * Date:
 * File: database.php
 * Description:
 */

//set mysql error report mode
mysqli_report(MYSQLI_REPORT_ERROR);
//define parameters
$host = "localhost";
$login = "phpuser";
$password = "phpuser";
// I have it as colts_db1 on my end, alter this to the name you have on your localhost
$database = "colts_db";
$tblProducts = "products";
$tblCustomer = "customers";
// I think there might need to be a space between these words
$tblInvoice = "invoice details";
$tblPrimOrder = "primary order";
//not sure if this is needed or not but here we go
$tblTypes = "types";


//Connect to the mysql server
$conn = @new mysqli($host, $login, $password, $database);

//Handle connection errors
if ($conn->connect_errno) {
    $error = $conn->connect_error;
    header("Location: error.php?m=$error");
    die();
}

?>